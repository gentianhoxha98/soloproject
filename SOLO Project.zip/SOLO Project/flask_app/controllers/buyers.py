from flask_app import app
from flask import render_template, request, session, redirect, flash,jsonify
from flask_bcrypt import Bcrypt 
from flask_app.models.buyer import Buyer
from flask_app.models.car import Car
bcrypt = Bcrypt(app)

@app.route('/')
def index():
    if 'buyer_id' in session:
        return redirect('/buyer/dashboard')
    return redirect('/logout')

@app.route('/register/buyer', methods = ['POST'])
def register():
    if 'buyer_id' in session:
        return redirect('/')
    if not Buyer.validate_buyerRegister(request.form):
        return redirect(request.referrer)
    
    data = {
        'firstName': request.form['firstName'],
        'lastName': request.form['lastName'],
        'description': request.form['description'],
        'email': request.form['email'],
        'password': bcrypt.generate_password_hash(request.form['password'])
    }
    session['buyer_id'] = Buyer.create(data)
    return redirect('/')


@app.route('/login')
def loginPage():
    if 'buyer_id' in session:
        return redirect('/buyer/dashboard')
    return render_template('buyerLoginRegister.html')


@app.route('/login/buyer', methods = ['POST'])
def login():
    if 'buyer_id' in session:
        return redirect('/')
    if not Buyer.validate_buyer(request.form):
        return redirect(request.referrer)
    buyer = Buyer.get_buyer_by_email(request.form)
    if not buyer:
        flash('This email doesnt exist', 'buyerEmailLogin')
        return redirect(request.referrer)
    
    if not bcrypt.check_password_hash(buyer['password'], request.form['password']):
        flash('Incorrect password', 'buyerPasswordLogin')
        return redirect(request.referrer)
    
    session['buyer_id']= buyer['id']
    return redirect('/')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

@app.route('/buyer/dashboard')
def dashboardBuyer():
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        'id': session['buyer_id']
    }
    buyer = Buyer.get_buyer_by_id(data)
    print(buyer)
    properties = Car.get_all()
    return render_template('buyerdashboard.html', loggedBuyer = buyer, properties=properties)

@app.route('/buyer/profile')
def buyerProfile():
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        'id': session['buyer_id']

    }
    
    loggedBuyer = Buyer.get_buyer_by_id(data)
    return render_template('buyerProfile.html', loggedBuyer = loggedBuyer)

@app.route('/buyer/editprofile')
def buyerEditProfile():
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        'id': session['buyer_id'],

    }
    buyer = Buyer.get_buyer_by_id(data)
    
    return render_template('buyerEditProfile.html', loggedBuyer = buyer)

@app.route('/buyer/editprofile', methods = ['POST'])
def updateBuyerProfile():
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        'id': session['buyer_id']
    }
    buyer = Buyer.get_buyer_by_id(data)
    if buyer['id'] == session['buyer_id']:
        if not Buyer.validate_buyerUpdate(request.form):
            return redirect(request.referrer)
        data = {
            'email': request.form['email'],
         
            'description': request.form['description'],
            'id': session['buyer_id']
            
        }
        Buyer.update(data)
        return redirect('/buyer/profile')
    return redirect('/')