from flask_app import app
from flask import render_template, request, session, redirect, flash,jsonify
from flask_bcrypt import Bcrypt 
from flask_app.models.owner import Owner
from flask_app.models.car import Car
from flask_app.models.buyer import Buyer
bcrypt = Bcrypt(app)

from datetime import datetime
from urllib.parse import unquote
UPLOAD_FOLDER = 'flask_app/static/images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

import os
from werkzeug.exceptions import RequestEntityTooLarge

from werkzeug.utils import secure_filename
from werkzeug.datastructures import  FileStorage
from werkzeug.exceptions import HTTPException, NotFound
import urllib.parse

import smtplib


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/owner/cars/new')
def car():
    if 'owner_id' not in session:
        return redirect('/carOwner')
    data = {
        'owner_id': session['owner_id']
    }
    loggedOwner = Owner.get_owner_by_id(data)
    return render_template('newcar.html', loggedOwner = loggedOwner)


@app.route('/owner/cars/create', methods = ['POST'])
def createCar():
    if 'owner_id' not in session:
        return redirect('/carOwner')
    if not Car.validate_car(request.form):
        return redirect(request.referrer)
    if 'images' not in request.files:
        flash('Please upload an image', 'imagesCar')
        return redirect(request.referrer)
    carImages = request.files.getlist('images')
    image_filenames = []
    for carimage in carImages:
        if not allowed_file(carimage.filename):
            flash('The file should be in png, jpg or jpeg format!', 'imagesCar')
            return redirect(request.referrer)
    
        if carimage:
            filename1 = secure_filename(carimage.filename)
            time = datetime.now().strftime("%d%m%Y%S%f")
            time += filename1
            filename1 = time
            carimage.save(os.path.join(app.config['UPLOAD_FOLDER'], filename1))
            image_filenames.append(filename1)
            
    images_string = ','.join(image_filenames)
            
        
    data = {
        'type': request.form['type'],
        'address': request.form['address'],
        'price': request.form['price'],
        'description': request.form['description'],
        'images': images_string,
        'owner_id': session['owner_id']
    }
    Car.create(data)
    return redirect('/carOwner')
    

@app.route('/owner/cars/<int:id>')
def showOneCar(id):
    if 'owner_id' not in session:
        return redirect('/carOwner')
    data = {
        'owner_id':session['owner_id'],
        'id': id
    }
    owner = Owner.get_owner_by_id(data)
    car = Car.get_car_by_id(data)
    return render_template('ownerCar.html', car=car, loggedOwner = owner)


@app.route('/buyer/delete/comment/<int:id>')
def deleteComment(id):
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        'id': id
    }
    comment = Car.get_comment_by_id(data)
    
    if comment['buyer_id'] == session['buyer_id']:
        Car.deleteComment(data)
    return redirect(request.referrer)

@app.route('/buyer/comments/add/<int:id>', methods = ['POST'])
def createComment(id):
    if 'buyer_id' not in session:
        return redirect('/')
    if not Car.validate_carComment(request.form):
        return redirect(request.referrer)
    data = {
        'buyer_id': session['buyer_id'],
        'car_id': id,
        'comment': request.form['comment']
    }
    Car.addComment(data)
    return redirect(request.referrer)

@app.route('/buyer/cars/<int:id>')
def showOneBuyerCar(id):
    if 'buyer_id' not in session:
        return redirect('/')
    data = {
        
        'id': id
    }
    
    car = Car.get_car_by_id(data)
    
    return render_template('buyerCar.html', car=car)

@app.route('/owner/cars/delete/<int:id>')
def deleteCar(id):
    if 'owner_id' not in session:
        return redirect('/carOwner')
    data = {
        
        'id': id
    }
    car = Car.get_car_by_id(data)
    if car['owner_id'] == session['owner_id']:
        Car.deleteAllPostComments(data)
        Car.delete(data)
    return redirect('/carOwner')