from flask_app.config.mysqlconnection import connectToMySQL
import re
from flask import flash
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
PASWORD_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
class Buyer:
    db_name = "cars"
    def __init__(self, data):
        self.id = data['id']
        self.firstName = data['firstName']
        self.lastName = data['lastName']
        self.description = data['description']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_buyer_by_email(cls, data):
        query = 'SELECT * FROM buyers where email = %(email)s;'
        result = connectToMySQL(cls.db_name).query_db(query, data)
        if result:
            return result[0]
        return False
    
    @classmethod
    def get_buyer_by_id(cls, data):
        query = 'SELECT * FROM buyers where id = %(id)s;'
        result = connectToMySQL(cls.db_name).query_db(query, data)
        if result:
            return result[0]
        return False
    
    @classmethod
    def get_buyer_by_buyer_id(cls, data):
        query = 'SELECT * FROM buyers where id = %(buyer_id)s;'
        result = connectToMySQL(cls.db_name).query_db(query, data)
        if result:
            return result[0]
        return False
        
    
    @classmethod
    def create(cls, data):
        query = "INSERT INTO buyers (firstName, lastName, description, email, password) VALUES (%(firstName)s, %(lastName)s, %(description)s, %(email)s, %(password)s);"
        return connectToMySQL(cls.db_name).query_db(query, data)
    
    @classmethod
    def update(cls, data):
        query = "UPDATE buyers set email = %(email)s, description = %(description)s WHERE buyers.id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query, data)
    
    @staticmethod
    def validate_buyer(buyer):
        is_valid = True
        if not EMAIL_REGEX.match(buyer['email']): 
            flash("Invalid email address!", 'buyerEmailLogin')
            is_valid = False
        if len(buyer['password'])<8:
            flash("Password is required!", 'buyerPasswordLogin')
            is_valid = False
        return is_valid
    
    @staticmethod
    def validate_buyerRegister(buyer):
        is_valid = True
        if not EMAIL_REGEX.match(buyer['email']): 
            flash("Invalid email address!", 'buyerEmailRegister')
            is_valid = False
        if len(buyer['password'])<8:
            flash("Password should be minimum 8 characters!", 'buyerPasswordRegister')
            is_valid = False 
 
        if len(buyer['confirm_password'])<8:
            flash("Confirm Password should be minimum 8 characters!", 'buyerConfirmPasswordRegister')
            is_valid = False  
        if buyer['password'] != buyer['confirm_password']:
            flash("Your password is different from the confirmed password ", 'errorbuyerPasswordRegister')   
            is_valid = False 
        
        if len(buyer['firstName'])<1:
            flash("First name is required!", 'buyerNameRegister')
            is_valid = False
        if len(buyer['lastName'])<1:
            flash("Last name is required!", 'buyerlastNameRegister')
            is_valid = False
        if len(buyer['description'])<10:
            flash("Description should be minimum 10 characters!", 'buyerDescriptionRegister')
            is_valid = False 
        return is_valid
    @staticmethod
    def validate_buyerUpdate(buyer):
        is_valid = True
        if not EMAIL_REGEX.match(buyer['email']): 
            flash("Invalid email address!", 'buyerEmaiEdit')
            is_valid = False
        if len(buyer['description'])<10:
            flash("Description should be minimum 10 characters!", 'buyerDescriptionEdit')
            is_valid = False 
        return is_valid